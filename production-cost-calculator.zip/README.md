# Production Cost Calculator

React app to calculate daily and monthly profits for a plastic container manufacturing workshop.