
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";

export default function ProductionCostCalculator() {
  const [dailyProduction, setDailyProduction] = useState(0);
  const [unitPrice, setUnitPrice] = useState(0);
  const [monthlyRent, setMonthlyRent] = useState(38000);
  const [electricityCostPer1700kg, setElectricityCostPer1700kg] = useState(12000);
  const [electricityWeightRef, setElectricityWeightRef] = useState(1700);
  const [annualTax, setAnnualTax] = useState(0);
  const [rawMaterialCostPerKg, setRawMaterialCostPerKg] = useState(205);
  const [unitWeightGrams, setUnitWeightGrams] = useState(150);
  const [capCostPerUnit, setCapCostPerUnit] = useState(3.21);
  const [colorantCost, setColorantCost] = useState(15000);
  const [colorantWeightRefKg, setColorantWeightRefKg] = useState(945);
  const [bagCost, setBagCost] = useState(100);
  const [bagUnitsCount, setBagUnitsCount] = useState(50);
  const [workerWagePerDay, setWorkerWagePerDay] = useState(1200);
  const [workingDaysInMonth, setWorkingDaysInMonth] = useState(30);
  const [monthlyOtherExpenses, setMonthlyOtherExpenses] = useState(12000);
  const [actualWorkingDays, setActualWorkingDays] = useState(0);
  const [nonWorkingDays, setNonWorkingDays] = useState(0);

  const totalUnitsMonth = dailyProduction * actualWorkingDays;

  const rentPerDay = monthlyRent / 30;
  const taxPerDay = annualTax / 12 / 30;
  const otherPerDay = monthlyOtherExpenses / 30;

  const electricityPerKg = electricityCostPer1700kg / electricityWeightRef;
  const plasticUsedKg = (unitWeightGrams / 1000) * dailyProduction;
  const electricityDailyCost = plasticUsedKg * electricityPerKg;
  const rawMaterialCost = plasticUsedKg * rawMaterialCostPerKg;

  const colorantPerKg = colorantCost / colorantWeightRefKg;
  const colorantUsedCost = plasticUsedKg * colorantPerKg;

  const capCost = dailyProduction * capCostPerUnit;
  const bagUsedCost = (dailyProduction / bagUnitsCount) * bagCost;
  const laborCost = workerWagePerDay;

  const dailyFixedCost = rentPerDay + taxPerDay + otherPerDay;
  const dailyVariableCost = electricityDailyCost + rawMaterialCost + colorantUsedCost + capCost + bagUsedCost + laborCost;

  const totalDailyCostWorking = dailyFixedCost + dailyVariableCost;
  const totalDailyCostNonWorking = rentPerDay + taxPerDay + otherPerDay;

  const totalMonthlyCost = (totalDailyCostWorking * actualWorkingDays) + (totalDailyCostNonWorking * nonWorkingDays);
  const totalRevenue = unitPrice * totalUnitsMonth;
  const netProfit = totalRevenue - totalMonthlyCost;

  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card>
        <CardContent className="space-y-3 p-4">
          <h2 className="text-xl font-bold">إدخال البيانات</h2>
          <Input type="number" placeholder="عدد البدون في اليوم" onChange={e => setDailyProduction(+e.target.value)} />
          <Input type="number" placeholder="سعر بيع البدون الواحد" onChange={e => setUnitPrice(+e.target.value)} />
          <Input type="number" placeholder="الكراء الشهري" value={monthlyRent} onChange={e => setMonthlyRent(+e.target.value)} />
          <Input type="number" placeholder="تكلفة الكهرباء لـ 1700كغ" value={electricityCostPer1700kg} onChange={e => setElectricityCostPer1700kg(+e.target.value)} />
          <Input type="number" placeholder="الوزن المرجعي للكهرباء (كغ)" value={electricityWeightRef} onChange={e => setElectricityWeightRef(+e.target.value)} />
          <Input type="number" placeholder="الضريبة السنوية" onChange={e => setAnnualTax(+e.target.value)} />
          <Input type="number" placeholder="سعر الكيلوغرام من البلاستيك" value={rawMaterialCostPerKg} onChange={e => setRawMaterialCostPerKg(+e.target.value)} />
          <Input type="number" placeholder="وزن البدون (غرام)" value={unitWeightGrams} onChange={e => setUnitWeightGrams(+e.target.value)} />
          <Input type="number" placeholder="ثمن الغطاء" value={capCostPerUnit} onChange={e => setCapCostPerUnit(+e.target.value)} />
          <Input type="number" placeholder="تكلفة الملون" value={colorantCost} onChange={e => setColorantCost(+e.target.value)} />
          <Input type="number" placeholder="وزن مرجعي للملون (كغ)" value={colorantWeightRefKg} onChange={e => setColorantWeightRefKg(+e.target.value)} />
          <Input type="number" placeholder="تكلفة الكيس" value={bagCost} onChange={e => setBagCost(+e.target.value)} />
          <Input type="number" placeholder="عدد البدون في كل كيس" value={bagUnitsCount} onChange={e => setBagUnitsCount(+e.target.value)} />
          <Input type="number" placeholder="أجرة العامل اليومية" value={workerWagePerDay} onChange={e => setWorkerWagePerDay(+e.target.value)} />
          <Input type="number" placeholder="أيام العمل في الشهر" value={workingDaysInMonth} onChange={e => setWorkingDaysInMonth(+e.target.value)} />
          <Input type="number" placeholder="مصاريف أخرى شهرية" value={monthlyOtherExpenses} onChange={e => setMonthlyOtherExpenses(+e.target.value)} />
          <Input type="number" placeholder="عدد أيام العمل الفعلية" onChange={e => setActualWorkingDays(+e.target.value)} />
          <Input type="number" placeholder="عدد أيام التوقف" onChange={e => setNonWorkingDays(+e.target.value)} />
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-3 p-4">
          <h2 className="text-xl font-bold">النتائج</h2>
          <p>صافي الربح الشهري: <strong>{netProfit.toFixed(2)} دج</strong></p>
          <p>مجموع التكاليف الشهرية: <strong>{totalMonthlyCost.toFixed(2)} دج</strong></p>
          <p>الإيرادات الشهرية: <strong>{totalRevenue.toFixed(2)} دج</strong></p>
        </CardContent>
      </Card>
    </div>
  );
}
